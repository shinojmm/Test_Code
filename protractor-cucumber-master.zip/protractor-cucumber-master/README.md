# Test Angular using CucumberJs

* Angular - the code to test
* Protractor - test executor
* Cucumber - to write test in plain language

## Setup
Assuming you already have an existing Angular app

npm install 

npm run ng build

npm run ng serve

npm run ng e2e 

