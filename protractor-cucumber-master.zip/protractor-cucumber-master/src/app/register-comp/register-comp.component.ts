import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-comp',
  templateUrl: './register-comp.component.html',
  styleUrls: ['./register-comp.component.css']
})
export class RegisterCompComponent implements OnInit {
  firstName ='First Name';
  constructor() { }

  ngOnInit() {
  }

}
